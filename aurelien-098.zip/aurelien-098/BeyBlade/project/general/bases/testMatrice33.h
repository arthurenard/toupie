#ifndef TESTMATRICE33_H
#define TESTMATRICE33_H
#include <iostream>
#include "Matrice33.h"
#include "Vecteur.h"

void testMatrice();

#endif // TESTMATRICE33_H
