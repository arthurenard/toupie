#ifndef TESTVECTEUR_H
#define TESTVECTEUR_H
#include <iostream>
#include "Vecteur.h"

void testVecteur();

#endif // TESTVECTEUR_H
