#include <iostream>

#include "Toupie.h"
#include "Vecteur.h"

using namespace std;

int main(){
	Vecteur pos(2), vit(2);
	Toupie qlq(pos, vit);
	
	return 0;
}
