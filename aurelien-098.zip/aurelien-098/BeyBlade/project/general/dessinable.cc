#include "dessinable.h"

Dessinable::Dessinable(SupportADessin* support)
    : support(support)
  {}

Dessinable::~Dessinable()
{}
