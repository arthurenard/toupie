#ifndef VERTEX_SHADER_H
#define VERTEX_SHADER_H

enum Attribute_Id {
  SommetId = 0,
  CoordonneeTextureId,
  CouleurId,
};

#endif
